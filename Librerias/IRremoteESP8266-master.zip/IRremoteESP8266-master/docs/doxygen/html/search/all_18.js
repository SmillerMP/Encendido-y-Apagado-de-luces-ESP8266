var searchData=
[
  ['xfan_3531',['XFan',['../unionKelvinatorProtocol.html#a44a0ba82ee5dc39f64215d26edb9636c',1,'KelvinatorProtocol::XFan()'],['../unionGreeProtocol.html#a3fbf66dfc2043710c5e00f8230eddb48',1,'GreeProtocol::Xfan()']]],
  ['xmp_3532',['XMP',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada009e712c328b21b54c2a099ec8520585',1,'IRremoteESP8266.h']]],
  ['xorbytes_3533',['xorBytes',['../IRutils_8cpp.html#aaa2a3fb714375e61051a0b24623b9cc9',1,'xorBytes(const uint8_t *const start, const uint16_t length, const uint8_t init):&#160;IRutils.cpp'],['../IRutils_8h.html#ab030689a93499311ee8e6621ac8757aa',1,'xorBytes(const uint8_t *const start, const uint16_t length, const uint8_t init=0):&#160;IRutils.cpp']]]
];
